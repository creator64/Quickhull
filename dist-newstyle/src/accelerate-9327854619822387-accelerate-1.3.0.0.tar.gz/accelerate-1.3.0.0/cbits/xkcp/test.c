
#include "KeccakHash.h"
#include <stdio.h>

int main()
{
  printf("sizeof(Keccak_HashInstance) = %ld\n", sizeof(Keccak_HashInstance));
  return 0;
}

